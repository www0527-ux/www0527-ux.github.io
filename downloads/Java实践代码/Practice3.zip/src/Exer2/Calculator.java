package Exer2;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Calculator {
    //首先写一个界面出来
    JFrame frame=new JFrame("Calculator");
    JTextField text=new JTextField("0");
    String firstNum;
    String lastNum="";
    String operator="";
    String content="";
    boolean isNewNum=false;
    boolean equalIs=false;
    void print(){
        //绘制界面
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());
        //将其添加至最上方
        //设置文本框
        text.setEditable(false);
        text.setFont(new Font("宋体",Font.PLAIN,30));
        text.setHorizontalAlignment(JTextField.RIGHT);
        frame.add(text,BorderLayout.NORTH);
        //设置按钮//如何布局呢？
        JPanel buttonPanel=new JPanel();
        buttonPanel.setLayout(new GridLayout(4,4,0,0));
        String[] buttonText={
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "C", "0", "=", "+"
        };
        for(String temp:buttonText){
            JButton button=new JButton(temp);
            button.setFont(new Font("宋体",Font.PLAIN,20));
            button.addActionListener(new ActionListener() {
                //下面重写
                public void actionPerformed(ActionEvent e){
                    //这个e的作用是什么？
                    String butText=e.getActionCommand();
                     // 根据按钮文本，分情况处理
                    if (butText.equals("C")) {
                       clearAll();
                    } else if (butText.equals("+") || butText.equals("-") || butText.equals("*") || butText.equals("/")) {
                      
                        handleOperator(butText);
                    } else if (butText.equals("=")) {
                        
                        calculate();
                    } else {
                        if(!equalIs){
                            //表示刚刚输入了赋值符号
                            handleNumber(butText);
                        }
                       
                    }
                }
            });
            buttonPanel.add(button);
        }
        frame.add(buttonPanel,BorderLayout.CENTER);
        //设置可见
        frame.setVisible(true);
    }
    static public void main(String[] args){
        Calculator cal=new Calculator();
        cal.print();
    }
    private void handleOperator(String op) {
        firstNum = text.getText();
        operator = op; // 记录运算符
        //下面进行修改，将前面的内容都保存下来
        content=text.getText()+operator;
        isNewNum = true; // 标记接下来要输入第二个数，后续数字会替换显示框
        equalIs=false;
    }
    private void handleNumber(String butText){
        //需要判断是否是第一个数字
        if(isNewNum==true){
            //表示是第二个数字
            text.setText(content+butText);
            content=content+butText;
            lastNum=lastNum+butText;
        }
        else{
            if(text.getText().equals("0")){
                //这里我用了等号来判断引用是有问题的
                text.setText(butText);
            }
            else{
                text.setText(text.getText()+butText);
            }
        }
    }
      private void calculate() {
        try {
            // 把字符串转换为数字（支持小数）
            double num1 = Double.parseDouble(firstNum);
            double num2 = Double.parseDouble(lastNum);//text为当前的数字
            double result = 0;
            System.out.println("num1:"+num1+"  num2:"+num2);
            // 根据运算符计算
            switch (operator) {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "*":
                    result = num1 * num2;
                    break;
                case "/":
                    if (num2 == 0) { // 处理除数为0的错误
                        text.setText("错误");
                        isNewNum = true;
                        return; // 直接返回，不执行后续代码
                    }
                    result = num1 / num2;
                    break;
            }

            // 优化显示：如果是整数（比如6.0），显示为整数；否则显示小数
            if (result == (int) result) {
                text.setText(String.valueOf((int) result));
            } else {
                text.setText(String.valueOf(result));
            }
            equalIs=true;
            isNewNum = true; // 计算后，标记已经输入了第一个数字
            content=text.getText();
            lastNum="";
        } catch (Exception e) {
            // 异常情况（比如没输入数字就点等号），显示错误
            text.setText("错误");
            isNewNum = true;
        }
    }

    // --------------- 工具方法4：清空所有状态（C按钮）---------------
    private void clearAll() {
        text.setText("0"); // 显示框重置为0
        firstNum = ""; // 清空第一个操作数
        lastNum="";
        operator = ""; // 清空运算符
        content="";
        isNewNum = false; 
    }

}
