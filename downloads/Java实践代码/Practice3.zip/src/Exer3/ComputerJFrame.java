package Exer3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ComputerJFrame extends JFrame implements ActionListener {
    // 使用Swing组件替换AWT组件
    JTextField textOne, textTwo, textResult;
    JButton getProblem, giveAnswer;
    JLabel operatorLabel, message, equal;
    Teacher teacher;
    
    ComputerJFrame(String s) {
        super(s);
        teacher = new Teacher();
        
        // 设置布局管理器
        setLayout(new FlowLayout());
        
        // 创建Swing组件
        textOne = new JTextField("", 10); 
        textTwo = new JTextField("", 10); 
        textResult = new JTextField("", 10);
        operatorLabel = new JLabel("+");
        equal = new JLabel("=");  
        message = new JLabel("你还没有回答呢");
        getProblem = new JButton("获取题目");
        giveAnswer = new JButton("确认答案");
        
        // 设置字体以确保中文显示正常
        Font chineseFont = new Font("微软雅黑", Font.PLAIN, 12);
        textOne.setFont(chineseFont);
        textTwo.setFont(chineseFont);
        textResult.setFont(chineseFont);
        operatorLabel.setFont(chineseFont);
        equal.setFont(chineseFont);
        message.setFont(chineseFont);
        getProblem.setFont(chineseFont);
        giveAnswer.setFont(chineseFont);
        
        // 添加组件到窗口
        add(getProblem);
        add(textOne);
        add(operatorLabel);
        add(textTwo);
        add(equal);
        add(textResult);
        add(giveAnswer);
        add(message);
        
        // textResult 获得焦点
        textResult.requestFocusInWindow();
        
        // 设置textOne和textTwo不可编辑
        textOne.setEditable(false);
        textTwo.setEditable(false);
        
        // 注册事件监听器
        getProblem.addActionListener(this);
        giveAnswer.addActionListener(this);
        textResult.addActionListener(this);
        
        setLocation(100, 100);
        setSize(600, 150); // 调整窗口大小以适应组件
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // 添加窗口监听器
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        
        if (source == getProblem) {
            // 获取题目
            int number1 = teacher.giveNumberOne(100); // 扩大数字范围
            int number2 = teacher.giveNumberTwo(100);
            String operator = teacher.giveOperator();
            
            textOne.setText(String.valueOf(number1));
            textTwo.setText(String.valueOf(number2));
            operatorLabel.setText(operator);
            textResult.setText(""); // 清空答案框
            message.setText("请回答问题");
            
        } else if (source == giveAnswer || source == textResult) {
            // 处理答案
            String answer = textResult.getText();
            try {
                if (!answer.isEmpty()) {
                    if (teacher.getRight(Integer.parseInt(answer))) {
                        message.setText("你回答正确");
                    } else {
                        message.setText("你回答错误");
                    }
                }
            } catch (NumberFormatException ex) {
                message.setText("请输入数字字符");
            }
        }
        textResult.requestFocusInWindow();
    }
}