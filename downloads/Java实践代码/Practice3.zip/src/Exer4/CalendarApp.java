package Exer4;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

public class CalendarApp extends JFrame {
    private int currentYear;
    private int currentMonth;
    private JLabel[][] dateLabels = new JLabel[7][7];
    private JLabel infoLabel;

    public CalendarApp() {
        Calendar calendar = Calendar.getInstance();
        currentYear = calendar.get(Calendar.YEAR);
        currentMonth = calendar.get(Calendar.MONTH);
        setTitle("日历");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        JPanel northPanel = createNorthPanel();
        add(northPanel, BorderLayout.NORTH);
        JPanel centerPanel = createCenterPanel();
        add(centerPanel, BorderLayout.CENTER);
        JPanel southPanel = createSouthPanel();
        add(southPanel, BorderLayout.SOUTH);
        updateCalendar();
    }
    private JPanel createNorthPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        
        JButton prevBtn = new JButton("上月");
        JButton nextBtn = new JButton("下月");
        prevBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentMonth--;
                if (currentMonth < 0) {
                    currentMonth = 11;
                    currentYear--;
                }
                updateCalendar();
            }
        });
        
        nextBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentMonth++;
                if (currentMonth > 11) {
                    currentMonth = 0;
                    currentYear++;
                }
                updateCalendar();
            }
        });
        
        panel.add(prevBtn);
        panel.add(nextBtn);
        
        return panel;
    }
    private JPanel createCenterPanel() {
        JPanel panel = new JPanel(new GridLayout(7, 7, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // 设置星期标题
        String[] weeks = {"日", "一", "二", "三", "四", "五", "六"};
        for (int i = 0; i < 7; i++) {
            JLabel label = new JLabel(weeks[i], SwingConstants.CENTER);
            label.setFont(new Font("黑体", Font.BOLD, 14));
            label.setForeground(Color.RED);
            panel.add(label);
        }
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                JLabel label = new JLabel("", SwingConstants.CENTER);
                label.setFont(new Font("宋体", Font.PLAIN, 14));
                dateLabels[i][j] = label;
                panel.add(label);
            }
        }
        
        return panel;
    }
    private JPanel createSouthPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 10));
        
        infoLabel = new JLabel("", SwingConstants.CENTER);
        infoLabel.setFont(new Font("宋体", Font.PLAIN, 16));
        
        panel.add(infoLabel);
        
        return panel;
    }

    /**
     * 更新日历显示
     */
    private void updateCalendar() {
        // 清空所有日期标签
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                dateLabels[i][j].setText("");
            }
        }
        
        // 设置当前年月信息
        String[] months = {"一月", "二月", "三月", "四月", "五月", "六月", 
                          "七月", "八月", "九月", "十月", "十一月", "十二月"};
        infoLabel.setText(currentYear + "年 " + months[currentMonth]);
        
        // 获取当前月的第一天是星期几（0-6，0 是星期日）
        Calendar calendar = Calendar.getInstance();
        calendar.set(currentYear, currentMonth, 1);
        int firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK) - 1;
        
        int daysInMonth;
        if (currentMonth == 1) { 
            if (currentYear % 4 == 0 && currentYear % 100 != 0 || currentYear % 400 == 0) {
                daysInMonth = 29; 
            } else {
                daysInMonth = 28; 
            }
        } else if (currentMonth == 3 || currentMonth == 5 || currentMonth == 8 || currentMonth == 10) {
            daysInMonth = 30; 
        } else {
            daysInMonth = 31;
        }
        int row = 0;
        int col = firstDayOfWeek;
        //填充日期
        for(int day=1;day<=daysInMonth;day++){
            dateLabels[row][col].setText(String.valueOf(day));
            if((++col)==7){
                col=0;
                row++;
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CalendarApp().setVisible(true);
            }
        });
    }
}