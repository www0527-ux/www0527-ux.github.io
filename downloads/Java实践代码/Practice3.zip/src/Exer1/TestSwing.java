package Exer1;
import javax.swing.*;
public class TestSwing {
    /*
     * 基本组件/容器组件
     * 容器组件：JFrame，JDialog，JApplet
     * 中间容器
     * 布局管理器
     */
    public static  void main(String[] args){
        JFrame frame = new JFrame();
            frame.setTitle("我的窗口"); // 后续可手动设置标题
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(300, 300);
           
            frame.setLocationRelativeTo(null);
            JPanel panel=new JPanel();
            JLabel label=new JLabel("请点击按钮");
            panel.add(label);
            JButton button=new JButton("点击");
            panel.add(button);
            JTextField text=new JTextField("默认文字");
            panel.add(text);
            JTextArea textArea=new JTextArea("显示");
            panel.add(textArea);
            JCheckBox checkBox=new JCheckBox("选项一",true);//初始选项为选中
            JCheckBox checkBox2=new JCheckBox("选项二",true);
            panel.add(checkBox);
            panel.add(checkBox2);
            JRadioButton radioButton=new JRadioButton("选项一");
            JRadioButton radioButton2=new JRadioButton("选项二");
            ButtonGroup group=new ButtonGroup();
            //确保这是单选
            group.add(radioButton);
            group.add(radioButton2);
            panel.add(radioButton);
            panel.add(radioButton2);
            String[] data = {"Apple", "Banana", "Cherry", "Date", "Grape"};
            JList<String> list=new JList<>(data);
            list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
            JScrollPane scrollPane=new JScrollPane(list);
            list.setVisibleRowCount(3);
            //用scoll包裹list
            panel.add(scrollPane);

            JComboBox<String> combol=new JComboBox<>();
            combol.addItem("Java");
            combol.addItem("Python");
            String[] languages = {"Java", "Python", "C++", "JavaScript"};
            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(languages);
            JComboBox<String> combo3 = new JComboBox<>(model);
            panel.add(combol);
            panel.add(combo3);
            JMenu menu=new JMenu();
            JMenu filMenu=new JMenu("文件");
            JMenuBar menuBar=new JMenuBar();
            
            JMenuItem newItem=new JMenuItem("选项1");
            JMenuItem newItem2=new JMenuItem("选项2");
            filMenu.add(newItem);
            filMenu.addSeparator();
            filMenu.add(newItem2);
            menuBar.add(filMenu);
            menuBar.add(menu);
            frame.setJMenuBar(menuBar);
            frame.add(panel); 
            frame.setVisible(true);
        } 
    
}
