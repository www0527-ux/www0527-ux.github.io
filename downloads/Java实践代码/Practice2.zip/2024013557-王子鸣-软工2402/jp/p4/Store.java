package jp.p4;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import jp.p4.data.Mobile;
import jp.p4.data.Mp3Player;
import jp.p4.data.Product;

public class Store {
    public static void main(String[] args) {

        Mobile mobile1 = new Mobile("China Mobile", "E365", 1780);
        Mobile mobile2 = new Mobile("China Mobile", "M330", 1450);
        Mp3Player player1 = new Mp3Player("Meizo X3", 256, 399);
        Mp3Player player2 = new Mp3Player("Meizo E5", 512, 580);
        Mp3Player player3 = new Mp3Player("Xlive XM MP3 Play", 256, 930);
		Calendar calendar = Calendar.getInstance();
        calendar.set(2013, Calendar.MAY, 14, 22, 3, 41);
        calendar.set(Calendar.MILLISECOND, 54); 
        Date saleDate = calendar.getTime(); 

     
        mobile1.sell(106800, saleDate);
        mobile2.sell(116000, saleDate);
        player1.sell(7980, saleDate);
        player2.sell(17400, saleDate);
        player3.sell(46500, saleDate);

        Product[] products = {mobile1, mobile2, player1, player2, player3};
        Arrays.sort(products);

        String text = "";
        for (int index = 0; index < products.length; ++index) {
            text += products[index].toString() + "\n";
        }

        JOptionPane.showMessageDialog(null, "The products are:\n\n" + text + "\nThere are " + Product.getCount() + " products.");
    }
}