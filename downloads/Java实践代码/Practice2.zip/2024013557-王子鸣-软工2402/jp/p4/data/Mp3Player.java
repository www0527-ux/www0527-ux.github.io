package jp.p4.data;

public class Mp3Player extends Product {
    private int capacity; 

    public Mp3Player(String name, int capacity, float price) {
        super(name, price);
        this.capacity = capacity;
    }

    @Override
    public String toString() {
        return name + ":" + price + " RMB,date and time of sale:" + formatDate() + ",sales:" + formatSales();
    }
}