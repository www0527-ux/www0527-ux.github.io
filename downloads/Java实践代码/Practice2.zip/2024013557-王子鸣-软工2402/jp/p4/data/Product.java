package jp.p4.data;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public abstract class Product implements Comparable<Product> {
    protected String name;
    protected float price;
    protected static int count;
    protected Date saleDate; 
    protected float sales;   

    protected Product(String name, float price) {
        this.name = name;
        this.price = price;
        ++count;
    }

    // 初始化销售日期和销售额
    public void sell(float sales, Date date) {
        this.sales = sales;
        this.saleDate = date;
    }

    // 格式化销售日期
    public String formatDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        return sdf.format(saleDate);
    }

    // 格式化销售额
    public String formatSales() {
        DecimalFormat df = new DecimalFormat("#,###,##0.00¥");
        return df.format(sales);
    }

    public String getName() {
        return name;
    }

    public float getPrice() {
        return price;
    }

    public static int getCount() {
        return count;
    }

    @Override
    public int compareTo(Product product) {
        return new Float(product.getPrice()).compareTo(price);
    }
}