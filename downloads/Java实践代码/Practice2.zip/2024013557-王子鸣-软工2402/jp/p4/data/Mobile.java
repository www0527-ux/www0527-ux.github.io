package jp.p4.data;

public class Mobile extends Product {
    private String brand;

    public Mobile(String brand, String name, float price) {
        super(name, price);
        this.brand = brand;
    }

    @Override
    public String toString() {
        return brand + " " + name + ":" + price + " RMB,date and time of sale:" + formatDate() + ",sales:" + formatSales();
    }
}