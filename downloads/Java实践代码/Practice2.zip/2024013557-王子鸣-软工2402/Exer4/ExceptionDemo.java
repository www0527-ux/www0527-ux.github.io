package Exer4;

public class ExceptionDemo {
    public static void main(String[] args){
                    String s=null;
                    int i,sum=0,a=5,b=0;
                    int c[]={1,2,3,4,5};
                    int len=s.length();
        try{
            
                    for(i=0;i<=5;i++){
                    sum=sum+c[i];
                    }
                    System.out.println("a/b"+a/b);
            }
        catch(NullPointerException e){
            System.out.println("捕获到空指针异常："+e.getMessage());
            e.printStackTrace();
        }
            catch(ArrayIndexOutOfBoundsException e){
                System.out.println("数组越界："+e.getMessage());
                e.printStackTrace();
            }
            catch (Exception e) {
            System.out.println("捕获到未知异常：" + e.getMessage());
            e.printStackTrace();
        } finally {
            System.out.println("===== 程序执行完毕 =====");
        }
    }
};
