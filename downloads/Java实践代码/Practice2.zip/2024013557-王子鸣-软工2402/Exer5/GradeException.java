package Exer5;

public class GradeException extends Exception{
    GradeException(){
        super("成绩输入有误");
    }
    GradeException(String in){
        super(in);
        //所有这些构造函数到底有哪些参数呢，有什么作用呢
    }
}
