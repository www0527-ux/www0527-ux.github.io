package Exer5;

import java.util.Scanner;

public class Grade {
    
    public static void main(String[] args) {
        Scanner reader=new Scanner(System.in);
        int countPass=0;
        int countNoPass=0;
        int studentNum=0;
        double TotalGrade=0;
        while(true){
            try{
                System.out.println("请输入班级人数：");
                studentNum=Integer.parseInt(reader.next());
                if(studentNum<0){
                    System.out.println("人数必须为正值！");
                    continue;
                }
                break;
            }
            catch(NumberFormatException e){
                System.out.println("输入错误，请输入数字:");
            }
        }
        double[] grade=new double[studentNum];
        for(int i=0;i<grade.length;i++){
            while(true){
                try{
                    System.out.println("请输入第"+i+"个学生成绩：");
                    grade[i]=Double.parseDouble(reader.next());
                    if(grade[i]<0||grade[i]>100){
                        throw new GradeException("成绩只能在0到100之间");
                    }
                    if(grade[i]<60){
                        countNoPass++;
                    }
                    else{
                        countPass++;
                    }
                    TotalGrade+=grade[i];
                    break;
                }
                catch(NumberFormatException e){
                    System.out.println("请输入数字！");
                }
                catch(GradeException e){
                    System.out.println(e.getMessage());
                    System.out.println("请重写输入正确的成绩（非负值）：");
                }
            }
        }
        double avgGrade=TotalGrade/studentNum;
        System.out.println("及格的人数是："+countPass);
        System.out.println("不及格的人数是："+countNoPass);
        System.out.println("平均分是："+avgGrade);

    }



}
