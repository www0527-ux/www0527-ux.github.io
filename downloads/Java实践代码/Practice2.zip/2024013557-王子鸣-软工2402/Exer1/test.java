package Exer1;

public class test {
	static public void main(String[] arg) {
		KeyWord test1=new KeyWord("this is a test","is");
		String answer1=test1.keywordSearch();
		KeyWord test2=new KeyWord("able was I ere I sawelba","a");
		String answer2=test2.keywordSearch();
		System.out.println(answer1);
		System.out.println(answer2);
	}
}