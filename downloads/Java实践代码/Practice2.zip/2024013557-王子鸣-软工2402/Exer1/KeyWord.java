package Exer1;

public class KeyWord {
	String input;
	String keyword;
//	String keywordSearch() {
//		//统计总次数
//		int len1=input.length();
//		int len2=keyword.length();
//		String answer="";
//		int count=0;
//		String index = "";
//		for(int i=0;i<len1;i++) {
//			int j;
//			for(j=0;j<len2;j++) {
//				if(input.charAt(i+j)!=keyword.charAt(j)) {
//					break;
//				}
//			}
//			if(j==len2) {
//				count++;
//				String temp=i+" ";
//				index+=temp;
//				i+=len2;
//			}
//		}
//		answer=count+":"+index;
//		return answer;
//	}
//	KeyWord(String input,String keyword){
//		this.input=input;
//		this.keyword=keyword;
//	}
	String keywordSearch() {
		//统计总次数
		int len1=input.length();
		int len2=keyword.length();
		String answer="";
		int count=0;
		StringBuffer index=new StringBuffer("");
		for(int i=0;i<len1;i++) {
			int j;
			for(j=0;j<len2;j++) {
				if(input.charAt(i+j)!=keyword.charAt(j)) {
					break;
				}
			}
			if(j==len2) {
				count++;
				index.append(i+" ");
				i+=len2;
			}
		}
		answer=count+":"+index;
		return answer;
	}
	KeyWord(String input,String keyword){
		this.input=input;
		this.keyword=keyword;
	}
	
	
}