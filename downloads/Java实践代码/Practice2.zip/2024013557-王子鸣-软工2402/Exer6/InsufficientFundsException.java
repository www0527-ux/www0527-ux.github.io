package Exer6;

public class InsufficientFundsException extends Exception{
    protected double dAmount; 
    void exceMessage(Bank bank){
        //为什么函数不能传入指针？
        //java里面没有指针，只有引用
        double balance=bank.show_balance();
        System.out.println("您的取款金额为："+this.getMessage()+"，但是账户余额仅为"+balance+"，操作不合法!");    

    }
    InsufficientFundsException(String message,Bank bank){
        super(message);
    }
}
