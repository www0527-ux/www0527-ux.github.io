package Exer6;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionDemo {
    
    static public void main(String[] args){
        double InitAmount=0;
        Scanner scanner=new Scanner(System.in);
        Bank bank=new Bank(InitAmount); 
    while(true){
        try{
                System.out.println("请输入初始存入金额：");
                InitAmount=scanner.nextDouble(); 
                bank.deposit(InitAmount);  
                
                //为什么不能在这里创建bank
                //因为bank的变量名本身是在栈中的，生命周期短。
                break;
        }
        catch(InputMismatchException e){
            System.out.println("请输入正确的格式！（数字）");
            scanner.next();
        }
    }
        System.out.println("测试取款功能");
        try{
            //存钱
            System.out.println("请输入要取出的钱");
            double output=scanner.nextDouble();
            bank.withdrawal(output);
            System.out.println("当前存款为："+bank.show_balance());
        }
        catch(InsufficientFundsException e){
            e.exceMessage(bank);
        }
        finally{
            System.out.println("操作退出！");
        }
    }
    
}
