package Exer6;

public class Bank{
    protected double balance;
    Bank(double balance){
        this.balance=balance;
    }
    void deposit(double dAmount){
        balance+=dAmount;
    }
    double withdrawal(double dAmount)throws InsufficientFundsException{
        if(dAmount>balance){
            throw new InsufficientFundsException(Double.toString(dAmount),this);
        }
        else{
            balance-=dAmount;
            return dAmount;
        }
    }
    double show_balance(){
        return balance;
    }
}
